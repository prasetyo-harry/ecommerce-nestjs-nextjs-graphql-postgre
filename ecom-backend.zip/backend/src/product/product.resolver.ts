import { Resolver, Query, Args } from '@nestjs/graphql';
import { ProductService } from './product.service';

@Resolver('Product')
export class ProductResolver {
  constructor(private productService: ProductService) {}

  @Query(() => [Object])
  async products() {
    return this.productService.findAll();
  }

  @Query(() => Object, { nullable: true })
  async product(@Args('id') id: string) {
    return this.productService.findOne(id);
  }
}
