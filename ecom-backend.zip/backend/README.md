# Ecom Backend (NestJS + Apollo GraphQL + Prisma)

## What is included
- NestJS minimal app (TypeScript)
- Apollo GraphQL configured to generate schema to `src/schema.gql`
- Prisma schema and seed script for PostgreSQL

## Setup (Windows PowerShell)

### Prerequisites
- Node.js >=18, npm
- PostgreSQL installed locally (not Docker)

### Steps
1. Install dependencies:
   ```powershell
   cd backend
   npm install
   ```

2. Configure environment:
   Copy `.env.example` to `.env` and adjust if needed (ensure PostgreSQL user/password/db are correct).

3. Initialize database:
   ```powershell
   npx prisma generate
   npx prisma migrate dev --name init
   node prisma/seed.js
   ```

4. Run backend:
   ```powershell
   npm run start:dev
   ```

Backend GraphQL playground: http://localhost:4000/graphql
