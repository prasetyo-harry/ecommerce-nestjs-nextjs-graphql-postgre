# Ecom Frontend (Next.js + Apollo Client)

## Setup (Windows PowerShell)

### Prerequisites
- Node.js >=18, npm
- Backend running at http://localhost:4000/graphql

### Steps
1. Install dependencies:
   ```powershell
   cd frontend
   npm install
   ```

2. Run dev server:
   ```powershell
   npm run dev
   ```

3. Open http://localhost:3000
