import { gql, useQuery } from '@apollo/client';
import Link from 'next/link';

const PRODUCTS = gql`
  query Products { products { id title description price sku } }
`;

export default function Home(){
  const { data, loading, error } = useQuery(PRODUCTS);
  if (loading) return <p>Loading...</p>
  if (error) return <p>Error: {error.message}</p>

  return (
    <div style={{ padding: 20 }}>
      <h1>Products</h1>
      <ul>
        {data.products.map((p:any) => (
          <li key={p.id}>
            <Link href={`/product/${p.id}`}><a>{p.title} — ${p.price}</a></Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
