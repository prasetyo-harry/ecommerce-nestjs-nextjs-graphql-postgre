import { useRouter } from 'next/router'
import { gql, useQuery } from '@apollo/client';

const PRODUCT = gql`
  query Product($id: String!) { product(id: $id) { id title description price sku } }
`;

export default function ProductPage(){
  const router = useRouter();
  const { id } = router.query;
  const { data, loading } = useQuery(PRODUCT, { variables: { id } as any, skip: !id });
  if (loading) return <p>Loading...</p>
  if (!data) return <p>No product</p>
  const p = data.product;
  return (
    <div style={{ padding: 20 }}>
      <h1>{p.title}</h1>
      <p>{p.description}</p>
      <p>${p.price}</p>
    </div>
  )
}
