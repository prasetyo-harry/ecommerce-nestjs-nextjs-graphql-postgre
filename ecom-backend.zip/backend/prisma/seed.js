const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main(){
  await prisma.product.createMany({ data: [
    { title: 'T-Shirt', description: 'A comfy t-shirt', price: 18.99, sku: 'TSHIRT-001' },
    { title: 'Mug', description: 'Coffee mug', price: 8.5, sku: 'MUG-001' }
  ]});
  console.log('Seed complete');
}

main().catch(e => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
